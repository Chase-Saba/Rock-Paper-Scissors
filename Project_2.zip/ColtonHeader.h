#ifndef COLTONHEADER_H   
#define COLTONHEADER_H
#include <iostream>
#include <ctime>
#include <random>
using namespace std;

class Colton_Alg {
    public: 
    char Algorithm1(char wtl[], char opp_array[], int rounds);
    char BigBadEvilCode(char wtl[], char opp_array[], int rounds);
    
};


#endif 
