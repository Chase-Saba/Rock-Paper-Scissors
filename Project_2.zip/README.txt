Before compiling, enter your code into the BigBadEvilCode function in the Algorithms.cpp file. There is already code in there, 
so simply just delete the existing code in the function and insert yours.


to compile the program you have to have the header file, main, and all the .cpp's that contain the algorithms
then type g++ main.cpp Algorithms.cpp ColtonHeader.h

When you run main it will run the algorithm 1 and 2 against each other


